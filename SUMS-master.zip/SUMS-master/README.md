# SUMS
Capstone Project

git clone https://github.com/ZhaoC/SUMS

cd SUMS

git checkout -b test

change password to your Database Password in file
'\SUMS\src\main\java\com\capstone\managedController\LoginValidate.java' and 'Capstone\SUMS\src\main\webapp\WEB-INF\applicationContext.xml'

mvn clean

mvn install

start tomcat and deployee war file
