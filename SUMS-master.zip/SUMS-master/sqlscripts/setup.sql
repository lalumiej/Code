# Drop database sums if it exists already
DROP DATABASE IF EXISTS sums;

# Create database
CREATE DATABASE sums;

# Choose database
USE sums;

# UTF-8 encode
SET NAMES 'utf8';

create table user(
userId			int				NOT NULL AUTO_INCREMENT PRIMARY KEY,
userPassword	varchar(255)	NOT NULL,
userFirstName	varchar(30)		NOT NULL,
userLastName	varchar(30)		NOT NULL,
userGender		varchar(10)		NOT NULL,
userBirth		date			NOT NULL,
userEmail		varchar(30)		NOT NULL,
userPhone		varchar(30)
);

create table club(
clubId			int				NOT NULL AUTO_INCREMENT PRIMARY KEY,
clubName		varchar(30)		NOT NULL,
clubCategory	varchar(30)		NOT NULL,
clubInitDate	date		NOT NULL,
clubStatus		varchar(15) 	NOT NULL,
clubNote		varchar(500)
);

create table role(
roleId			int				NOT NULL AUTO_INCREMENT PRIMARY KEY,
roleTitle		varchar(30)		NOT NULL,
rolePrivilege	varchar(30)		NOT NULL,
userId			int				NOT NULL,
clubId			int				NOT NULL,
roleInitDate	date		NOT NULL,
roleStatus		varchar(10)		NOT NULL
);

create table activity(
actId			int				NOT NULL AUTO_INCREMENT PRIMARY KEY,
clubId			int				NOT NULL,
actName			varchar(30)		NOT NULL,
actStartDate	datetime		NOT NULL,
actEndDate		datetime		NOT NULL,
actStatus		varchar(15) 	NOT NULL,
actCapacity		int				NOT NULL,
actLocation		varchar(300)	NOT NULL,
actBudget		int,
actAssignee		int 			NOT NULL,
actNote			varchar(500)
);

create table clubRegistrationRequest(
cRequestId		int				NOT NULL AUTO_INCREMENT PRIMARY KEY,
userId			int				NOT NULL,
clubId			int				NOT NULL,
requestCRole	varchar(30)		NOT NULL,
requestDate		datetime		NOT NULL,
requestStatus	varchar(10)
);

create table activityRegistrationRequest(
aRequestId		int				NOT NULL AUTO_INCREMENT PRIMARY KEY,
userId			int				NOT NULL,
actId			int				NOT NULL,
requestDate		datetime		NOT NULL,
requestStatus	varchar(10)		NOT NULL
);

create table message(
mesId			int				NOT NULL PRIMARY KEY,
mesSender		int				NOT NULL,
mesReceiver		int				NOT NULL,
mesSendTime		datetime		NOT NULL,
mesSubject		varchar(40)		NOT NULL,
mesCC			varchar(40),
mesBCC			varchar(40),
mesDetails		varchar(2000)
);


# insert data
#-----------------------------------------------------------------------------------------
INSERT INTO user (userId, userPassword, userFirstName, userLastName, userGender, userBirth, userEmail, userPhone)
  VALUES (100001, 'password', 'Lee', 'C', 'Male',  CURDATE(), '1@test.com', '0294023940');

INSERT INTO user (userId, userPassword, userFirstName, userLastName, userGender, userBirth, userEmail, userPhone)
  VALUES (100002, 'password', 'Gray', 'Y', 'Female',  CURDATE(), '2@test.com', '0294023940');

INSERT INTO user (userId, userPassword, userFirstName, userLastName, userGender, userBirth, userEmail, userPhone)
  VALUES (100003, 'password', 'Candy', 'H', 'Female',  CURDATE(), '3@test.com', '0294023940');



INSERT INTO club (clubId, clubName, clubCategory, clubInitDate, clubStatus, clubNote)
  VALUES (1001, 'CSSA', 'Test', CURDATE(), 'ACTIVE', 'This is only for test');

INSERT INTO club (clubId, clubName, clubCategory, clubInitDate, clubStatus, clubNote)
  VALUES (1002, 'Music Night', 'Test', CURDATE(), 'ACTIVE', 'This is only for test');

INSERT INTO club (clubId, clubName, clubCategory, clubInitDate, clubStatus, clubNote)
  VALUES (1003, 'Good and Evil', 'Test', CURDATE(), 'ACTIVE', 'This is only for test');

INSERT INTO club (clubId, clubName, clubCategory, clubInitDate, clubStatus, clubNote)
  VALUES (1004, 'Foo', 'Test', CURDATE(), 'ACTIVE', 'None One Join this club yet');


INSERT INTO activity (actId, clubId, actName, actStartDate, actEndDate, actStatus, actCapacity, actLocation, actBudget, actAssignee, actNote)
	VALUES (10001, 1001, 'Trip to  USA', curtime(), curtime(), 'ACTIVE', 100, 'Sheridan College', 400, 100001, 'test');

INSERT INTO activity (actId, clubId, actName, actStartDate, actEndDate, actStatus, actCapacity, actLocation, actBudget, actAssignee, actNote)
	VALUES (10002, 1001, 'Halloween Treat', curtime(), curtime(), 'ACTIVE', 100, 'Sheridan College', 400, 100001, 'test');

INSERT INTO activity (actId, clubId, actName, actStartDate, actEndDate, actStatus, actCapacity, actLocation, actBudget, actAssignee, actNote)
	VALUES (10003, 1002, 'Coldplay Concert', curtime(), curtime(), 'ACTIVE', 100, 'Sheridan College', 400, 100001, 'test');

INSERT INTO activity (actId, clubId, actName, actStartDate, actEndDate, actStatus, actCapacity, actLocation, actBudget, actAssignee, actNote)
	VALUES (10004, 1002, 'TIFF', curtime(), curtime(), 'ACTIVE', 100, 'Sheridan College', 400, 100001, 'test');




INSERT INTO role (roleId, roleTitle, rolePrivilege, userId, clubId, roleInitDate, roleStatus)
	VALUES (1000000, 'Manager', 'ADMIN', 100001, 1001, CURDATE(), 'ACTIVE');

INSERT INTO role (roleId, roleTitle, rolePrivilege, userId, clubId, roleInitDate, roleStatus)
	VALUES (1000001, 'Member', 'GUEST', 100001, 1002, CURDATE(), 'ACTIVE');

INSERT INTO role (roleId, roleTitle, rolePrivilege, userId, clubId, roleInitDate, roleStatus)
	VALUES (1000002, 'Member', 'GUEST', 100001, 1003, CURDATE(), 'ACTIVE');

INSERT INTO role (roleId, roleTitle, rolePrivilege, userId, clubId, roleInitDate, roleStatus)
	VALUES (1000003, 'Member', 'GUEST', 100002, 1001, CURDATE(), 'ACTIVE');

INSERT INTO role (roleId, roleTitle, rolePrivilege, userId, clubId, roleInitDate, roleStatus)
	VALUES (1000004, 'Member', 'GUEST', 100002, 1003, CURDATE(), 'ACTIVE');

INSERT INTO role (roleId, roleTitle, rolePrivilege, userId, clubId, roleInitDate, roleStatus)
	VALUES (1000005, 'Member', 'GUEST', 100003, 1003, CURDATE(), 'ACTIVE');


INSERT INTO clubregistrationrequest (cRequestId, userId, clubId, requestCRole, requestDate, requestStatus)
	VALUES (100001, 100001, 1001, 'GUEST', CURDATE(), 'ACTIVE');

INSERT INTO clubregistrationrequest (cRequestId, userId, clubId, requestCRole, requestDate, requestStatus)
	VALUES (100002, 100002, 1002, 'GUEST', CURDATE(), 'ACTIVE');


INSERT INTO activityRegistrationRequest( aRequestId, userId, actId, requestDate, requestStatus)
	VALUES (100001, 100001, 10001, CURDATE(), 'Approved');

INSERT INTO activityRegistrationRequest( aRequestId, userId, actId, requestDate, requestStatus)
	VALUES (100002, 100001, 10002, CURDATE(), 'Approved');

INSERT INTO activityRegistrationRequest( aRequestId, userId, actId, requestDate, requestStatus)
	VALUES (100003, 100001, 10003, CURDATE(), 'Approved');

INSERT INTO activityRegistrationRequest( aRequestId, userId, actId, requestDate, requestStatus)
	VALUES (100004, 100001, 10004, CURDATE(), 'Approved');

INSERT INTO activityRegistrationRequest( aRequestId, userId, actId, requestDate, requestStatus)
	VALUES (100005, 100002, 10001, CURDATE(), 'Approved');

INSERT INTO activityRegistrationRequest( aRequestId, userId, actId, requestDate, requestStatus)
	VALUES (100006, 100002, 10002, CURDATE(), 'Approved');

