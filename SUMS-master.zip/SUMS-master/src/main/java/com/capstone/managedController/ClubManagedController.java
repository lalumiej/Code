package com.capstone.managedController;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.capstone.slackChat.HttpURLConnectionSlack;
import com.capstone.spring.model.Club;
import com.capstone.spring.model.Role;
import com.capstone.spring.service.ClubService;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.springframework.dao.DataAccessException;
/**
 * Created by  Zhao Cai on 10/10/16.
 */

@ManagedBean(name="clubMB")
@RequestScoped
public class ClubManagedController implements Serializable {

    private static final String DEFAULT_ACTIVE_STATUS = "ACTIVE";
    private static final String DEFAULT_INIT_STATUS = "INIT";
    private static final String RENDER_MEMBER_CLUB = "member_clubs";

    //Spring Customer Service is injected...
    @ManagedProperty(value="#{ClubService}")
    ClubService clubService;

    @ManagedProperty("#{roleMB}")
    RoleManagedController roleManagedController;

    @ManagedProperty("#{loginValidate}")
    LoginValidate loginValidate;

    private static final long serialVersionUID = 1L;
    private static final String SUCCESS = "ViewClub";
    private static final String ERROR   = "error";


    /**
     * Club Entity Parameters
     */
    private int clubId;
    private String clubName;
    private String clubCategory;
    private Date clubInitDate;
    private String clubStatus;
    private String clubNote;

    /**
     * requested parameter
     */
    List<Club> clubList;
    List<Club> currentUserClubList;
    private Club selectedClub;
    private List<Club> selectedClubs;
    private List<Club> currentUserNotJoinedClubList;

    public String addClub() {
        try {
            Club club = new Club();
            club.setClubId(getClubId());
            club.setClubName(getClubName());
            club.setClubCategory(getClubCategory());
            club.setClubInitDate(new java.sql.Date(getClubInitDate().getTime()));
            club.setClubStatus(getClubStatus());
            club.setClubNote(getClubNote());

            getClubService().addClub(club);

            //Add new private channel/group in slack for the new club
//            String response = HttpURLConnectionSlack.createGroup(getClubName());
//            System.out.println(response);

            return "member_clubs";
        } catch (DataAccessException e) {
            e.printStackTrace();
        }

        return ERROR;
    }

    public String currentUserCreateNewClub() {
        try {
            Club club = new Club();
            club.setClubId(getClubId());
            club.setClubName(getClubName());
            club.setClubCategory(getClubCategory());
            club.setClubInitDate(new java.sql.Date(getClubInitDate().getTime()));
            //club.setClubStatus(getClubStatus());
            club.setClubStatus(DEFAULT_INIT_STATUS);
            club.setClubNote(getClubNote());

            //add club
            getClubService().addClub(club);

            Club justCreateClub = getClubService().getClubByStatusAndInitUser(DEFAULT_INIT_STATUS);
            
            //add manager role to user and update club status to active
            roleManagedController.addManagerRoleToUserCreatedNewClub(justCreateClub);
            justCreateClub.setClubStatus(DEFAULT_ACTIVE_STATUS);
            getClubService().updateClub(justCreateClub);

            return SUCCESS;
        } catch (DataAccessException e) {
            e.printStackTrace();
        }

        return ERROR;
    }

    public void deleteClub(){
        try {
            Club club = new Club();
            club = getClubService().getClubById(getClubId());
            getClubService().deleteClub(club);

        } catch (DataAccessException e) {
            e.printStackTrace();
        }
    }

    /**
     * Reset Fields
     *
     */
    public void reset() {
        this.setClubId(0);
        this.setClubName("");
        this.setClubCategory("");
        this.setClubInitDate(new Date());
        this.setClubStatus("");
        this.setClubNote("");
    }

    public void resetCreateClubFormFields() {
        this.setClubName("");
        this.setClubCategory("");
        this.setClubInitDate(new Date());
        this.setClubNote("");
    }

    /**
     * Get Club List
     *
     * @return List - Club List
     */
    public List<Club> getClubList() {
        clubList = new ArrayList<Club>();
        clubList.addAll(getClubService().getClubs());
        return clubList;
    }

    public ClubService getClubService() {
        return clubService;
    }

    public void setClubService(ClubService clubService) {
        this.clubService = clubService;
    }

    public void setClubList(List<Club> clubList) {
        this.clubList = clubList;
    }



    public int getClubId() {
        return clubId;
    }

    public void setClubId(int clubId) {
        this.clubId = clubId;
    }

    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public String getClubCategory() {
        return clubCategory;
    }

    public void setClubCategory(String clubCategory) {
        this.clubCategory = clubCategory;
    }

    public Date getClubInitDate() {
        return clubInitDate;
    }

    public void setClubInitDate(Date clubInitDate) {
        this.clubInitDate = clubInitDate;
    }

    public String getClubStatus() {
        return clubStatus;
    }

    public void setClubStatus(String clubStatus) {
        this.clubStatus = clubStatus;
    }

    public String getClubNote() {
        return clubNote;
    }

    public void setClubNote(String clubNote) {
        this.clubNote = clubNote;
    }

    public List<Club> getCurrentUserClubList() {
        currentUserClubList = new ArrayList<Club>();

        for(Integer clubId: roleManagedController.getClubIdListByUserId()){
            currentUserClubList.add(getClubService().getClubById(clubId));
        }
        return currentUserClubList;
    }

    public void setCurrentUserClubList(List<Club> currentUserClubList) {
        this.currentUserClubList = currentUserClubList;
    }

    public RoleManagedController getRoleManagedController() {
        return roleManagedController;
    }

    public void setRoleManagedController(RoleManagedController roleManagedController) {
        this.roleManagedController = roleManagedController;
    }

    public LoginValidate getLoginValidate() {
        return loginValidate;
    }

    public void setLoginValidate(LoginValidate loginValidate) {
        this.loginValidate = loginValidate;
    }


    /**
     * Slack Funtions:
     * Chan
     */

    /*
     Chan
     Test for Slack API call
     Create Channel
      */
    public String createChannel(){
        String name = "Zhao";
        HttpURLConnectionSlack.createChannel(name);
        return SUCCESS;
    }
    /*
    Chan
    Test for Slack API call
    Create Group
     */
    public String createGroup(){
        String name = "Jason";
        HttpURLConnectionSlack.createGroup(name);
        return SUCCESS;
    }
    /*
    Chan
    Test for Slack API call
    Invite User by Email
     */
    public String inviteUserByEmail(){
        String email = "caizh@sheridancollege.ca";
        HttpURLConnectionSlack.inviteUserByEmail(email);
        return SUCCESS;
    }
    /*
    Chan
    Test for Slack API call
    Invite User to a Channel
     */
    public String inviteUserToChannel(){
        String channelId = "C2Q2W07U2";
        String userId = "U2Q29M3QC";
        HttpURLConnectionSlack.inviteUserToChannel(channelId, userId);
        return SUCCESS;
    }
    /*
    Chan
    Test for Slack API call
    Invite User to a Group
     */
    public String inviteUserToGroup(){
        String groupId = "G2Q0WB6H1";
        String userId = "U2Q29M3QC";
        HttpURLConnectionSlack.inviteUserToGroup(groupId, userId);
        return SUCCESS;
    }

    /*
    Chan
    Test for Slack API call
    Get All Users
     */
    public String getAllUsers(){
        HttpURLConnectionSlack.getAllUsers();
        return SUCCESS;
    }

    /*
    Chan
    Test for Slack API call
    Get All Channels
     */
    public String getAllChannels(){
        HttpURLConnectionSlack.getAllChannels();
        return SUCCESS;
    }

    /*
    Chan
    Test for Slack API call
    Get All Groups
     */
    public String getAllGroups(){
        HttpURLConnectionSlack.getAllGroups();
        return SUCCESS;
    }

    /*
    Chan
    Test for Slack API call
    Get User by Name
     */
    public String getUserByName(){
        HttpURLConnectionSlack.getUserByName("xiaoqianyu");
        return SUCCESS;
    }

    /*
    Chan
    Test for Slack API call
    Get Channel by Name
     */
    public String getChannelByName(){
        HttpURLConnectionSlack.getChannelByName("meet");
        return SUCCESS;
    }

    /*
    Chan
    Test for Slack API call
    Get Group by Name
     */
    public String getGroupByName(){
        HttpURLConnectionSlack.getGroupByName("tea");
        return SUCCESS;
    }


    /**
     *Requested Parameters
     */
    public Club getSelectedClub() {
        return selectedClub;
    }

    public void setSelectedClub(Club selectedClub) {
        this.selectedClub = selectedClub;
    }

    public List<Club> getSelectedClubs() {
        return selectedClubs;
    }

    public void setSelectedClubs(List<Club> selectedClubs) {
        this.selectedClubs = selectedClubs;
    }

    public void onRowSelect(SelectEvent event) {
        FacesMessage msg = new FacesMessage("Club Selected", ((Club) event.getObject()).getClubName());
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }

    public void onRowUnselect(UnselectEvent event) {
        FacesMessage msg = new FacesMessage("Club Unselected", ((Club) event.getObject()).getClubName());
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }

    /**
     * join selected clubs for the current user
     */
    public String joinSelectedClubsForCurrentUser(){
        List<Club> userSelectedClubs = getSelectedClubs();
        getRoleManagedController().createMemberRolesForUserSelectedClubs(userSelectedClubs);
        return SUCCESS;
    }

    public List<Club> getCurrentUserNotJoinedClubList() {
        List<Club> allClubs = getClubList();
        List<Club> userJoinedClubs = getCurrentUserClubList();
        currentUserNotJoinedClubList= new ArrayList<Club>();

        for(int i=0; i<allClubs.size(); i++){
            if(!userJoinedClubs.contains(allClubs.get(i))){
                currentUserNotJoinedClubList.add(allClubs.get(i));
            }
        }
        return currentUserNotJoinedClubList;
    }

    public void setCurrentUserNotJoinedClubList(List<Club> currentUserNotJoinedClubList) {
        this.currentUserNotJoinedClubList = currentUserNotJoinedClubList;
    }
}