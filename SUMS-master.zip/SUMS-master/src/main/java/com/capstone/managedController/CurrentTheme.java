package com.capstone.managedController;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.io.Serializable;

/**
 * Created by  Zhao Cai on 10/17/16.
 */
@ManagedBean(name="currentTheme")
@SessionScoped
public class CurrentTheme implements Serializable{
    private String theme = "smoothness";

    public CurrentTheme(){

    }

    public String getTheme(){
        return theme;
    }

    public void setTheme(String theme){
        this.theme = theme;
    }
}
