/**  Author: Jason Lalumiere 
package com.capstone.managedController;


import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@ManagedBean(name="LoginBean")
@SessionScoped
public class LoginController implements Serializable{


	private static final long serialVersionUID = 1L;
	private String emailEntered;
    private String passwordEntered;
    private Date lastLogin;
 
    private String userPassword;
    private String userEmail;

    Connection connection;
    Statement statement;
    ResultSet resultSet;
    String SQL_UserId;
    String SQL_UserEmail;
	
	  public void dbData(String emailEntered) throws SQLException
	    {
	        try
	        {
	            Class.forName("com.mysql.jdbc.Driver");
	            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sums","root","root");
	            statement = connection.createStatement();
	            SQL_UserEmail = "Select * from user where userEmail = '"+ emailEntered+"'";
	            resultSet = statement.executeQuery(SQL_UserEmail);
	            resultSet.next();
	            userPassword = resultSet.getString(2).toString();
	            userEmail = resultSet.getString(7).toString();
	        }
	        catch(Exception ex)
	        {
	            ex.printStackTrace();
	            System.out.println("Exception Occured in the process :" + ex);
	        }finally {
	            connection.close();
	        }
	    }

	    public String checkValidUserByEmail() throws SQLException
	    {
	        dbData(emailEntered);
	        if(emailEntered.equals(getUserEmail()))
	        {
	            if(passwordEntered.equals(userPassword)){
	                return "member_homepage";
	            }
	            else
	            {
	                return "login";
	            }
	        }
	        else
	        {
	            return "login";
	        }
	    }


	    public String logout() {
	        ExternalContext ectx = FacesContext.getCurrentInstance().getExternalContext();
	        HttpServletResponse response = (HttpServletResponse)ectx.getResponse();
	        HttpSession session = (HttpSession)ectx.getSession(false);
	        session.invalidate();
	        return "login";
	    }

	    public String getEmailEntered() {
	        return emailEntered;
	    }

	    public void setEmailEntered(String emailEntered) {
	        this.emailEntered = emailEntered;
	    }

	    public String getUserEmail() {
	        return userEmail;
	    }

	    public void setUserEmail(String userEmail) {
	        this.userEmail = userEmail;
	    }

	   

	    public String getPasswordEntered() {
	        return passwordEntered;
	    }

	    public void setLoginInputPassword(String passwordEntered) {
	        this.passwordEntered = passwordEntered;
	    }

	   	    
	    public String getUserPassword() {
	        return userPassword;
	    }

	    public void setUserPassword(String userPassword) {
	        this.userPassword = userPassword;
	    }

		public Date getLastLogin() {
			return lastLogin;
		}

		public void setLastLogin(Date lastLogin) {
			this.lastLogin = lastLogin;
		}

}
*/