/**
package com.capstone.managedController;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;

import org.springframework.dao.DataAccessException;

import com.capstone.spring.model.Registration;
import com.capstone.spring.service.RegistrationService;

@ManagedBean(name="RegisterMB")
@RequestScoped
public class RegistrationManagedController implements Serializable{

	
	private static final long serialVersionUID = 1L;
    private static final String SUCCESS = "RegisterUser";
    private static final String ERROR   = "error";
    
    @ManagedProperty(value="#{RegistrationService}")
    RegistrationService registerService;

    List<Registration> registrationList;

    private int userId;
    private String userPassword;
    private String userFirstName;
    private String userLastName;
    private String userGender;
    private Date userBirth;
    private String userEmail;
    private String userPhone;

    public RegistrationService getRegistrationService() {
        return registerService;
    }

    public void setRegistrationService(RegistrationService registerService) {
        this.registerService = registerService;
    }


    public String addRegisteredUser() {
        try {
            Registration register = new Registration();
            register.setUserId(getUserId());
            register.setUserFirstName(getUserFirstName());
            register.setUserLastName(getUserLastName());
            register.setUserPassword(getUserPassword());
            register.setUserGender(getUserGender());
            register.setUserBirth(new java.sql.Date(getUserBirth().getTime()));
            register.setUserEmail(getUserEmail());
            register.setUserPhone(getUserPhone());

            getRegistrationService().registeredUser(register);
            return SUCCESS;
        } catch (DataAccessException e) {
            e.printStackTrace();
        }

        return ERROR;
    }


    /**
     * Reset Fields
     *
     */
    public void reset() {
        this.setUserId(0);
        this.setUserFirstName("");
        this.setUserLastName("");
        this.setUserPassword("");
        this.setUserGender("");
        this.setUserBirth(new Date());
        this.setUserEmail("");
        this.setUserPhone("");
    }



    /**
     * Get User List
     *
     * @return List - User List
     */
    public List<Registration> getRegisteredUser() {
        registrationList = new ArrayList<Registration>();
        registrationList.addAll(getRegistrationService().getRegisteredUsers());
        return registrationList;
    }


    public void setRegistrationList(List<Registration> registerList) {
        this.registrationList = registerList;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserFirstName() {
        return userFirstName;
    }

    public void setUserFirstName(String userFirstName) {
        this.userFirstName = userFirstName;
    }

    public String getUserLastName() {
        return userLastName;
    }

    public void setUserLastName(String userLastName) {
        this.userLastName = userLastName;
    }

    public String getUserGender() {
        return userGender;
    }

    public void setUserGender(String userGender) {
        this.userGender = userGender;
    }

    public Date getUserBirth() {
        return userBirth;
    }

    public void setUserBirth(Date userBirth) {
        this.userBirth = userBirth;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }
}

*/