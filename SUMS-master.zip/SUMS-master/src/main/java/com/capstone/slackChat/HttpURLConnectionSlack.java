package com.capstone.slackChat;

import org.primefaces.json.JSONArray;
import org.primefaces.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

/**
 * Created by Chan on 10/16/2016.
 */
public class HttpURLConnectionSlack {

    static final String HTTP_URL_CONNECTION_ERROR = "ERROR";
    static final String DO_NOT_FOUND_ERROR = "DIDN'T FOUND";

    //Token is used for slack authentication, manually generated online
    static final String token = "xoxp-89919973731-89981006535-91929924151-40f9aeb7fa174da4c4e01488f8fdcaf3";
    static final String url = "https://slack.com/api/";

    //Method used for creating a private group with name
    public static String createGroup (String name){
        return doPost("groups.create", new String[]{"name", name});
    }

    //Method used for creating a public channel with name
    public static String createChannel (String name){
        return doPost("channels.create", new String[]{"name", name});
    }

    //Method used for inviting new user to team by email
    public static String inviteUserByEmail (String email) {
        return doPost("users.admin.invite", new String[]{"email", email});
    }

    //Method used for inviting a user to a public channel
    public static String inviteUserToChannel (String channelId, String userId) {
        return doPost("channels.invite", new String[]{"channel", channelId, "user", userId});
    }

    //Method used for inviting a user to a private group
    public static String inviteUserToGroup (String channelId, String userId) {
        return doPost("groups.invite", new String[]{"channel", channelId, "user", userId});
    }

    //Method used for retrieving all users
    public static String getAllUsers (){
        return doPost("users.list",null);
    }

    //Method used for retrieving all channels
    public static String getAllChannels (){
        return doPost("channels.list",null);
    }

    //Method used for retrieving all groups
    public static String getAllGroups (){
        return doPost("groups.list",null);
    }

    //Method used for retrieving user info by user name
    public static String getUserByName(String name){
        JSONObject records = new JSONObject(getAllUsers());
        JSONArray members = records.getJSONArray("members");

        for ( int i = 0; i < members.length(); i++){
            JSONObject user = members.getJSONObject(i);
            String userName = user.getString("name");
            if( userName.equals(name)){
                System.out.println("-----------User Found-----------------");
                System.out.println(user.toString());
                System.out.println("-----------ID-----------------" + user.getString("id"));
                return user.toString();
            }
        }
        return DO_NOT_FOUND_ERROR;
    }

    //Method used for retrieving a channel info by channel name
    public static String getChannelByName(String name){
        JSONObject records = new JSONObject(getAllChannels());
        JSONArray channels = records.getJSONArray("channels");

        for ( int i = 0; i < channels.length(); i++){
            JSONObject chan = channels.getJSONObject(i);
            String channelName = chan.getString("name");
            if( channelName.equals(name)){
                System.out.println("-----------Channel Found-----------------");
                System.out.println(chan.toString());
                System.out.println("-----------ID-----------------" + chan.getString("id"));
                return chan.toString();
            }
        }
        return DO_NOT_FOUND_ERROR;
    }

    //Method used for retrieving a group info by group name
    public static String getGroupByName(String name){
        JSONObject records = new JSONObject(getAllGroups());
        JSONArray groups = records.getJSONArray("groups");

        for ( int i = 0; i < groups.length(); i++){
            JSONObject group = groups.getJSONObject(i);
            String groupName = group.getString("name");
            if( groupName.equals(name)){
                System.out.println("-----------Group Found-----------------");
                System.out.println(group.toString());
                System.out.println("-----------ID-----------------" + group.getString("id"));
                return group.toString();
            }
        }
        return DO_NOT_FOUND_ERROR;
    }

    //Method used for sending Http Post method
    public static String doPost(String function, String arg[]){

        StringBuffer response = new StringBuffer();

        try {
            URL obj = new URL (url + function);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();

            //add request header
            con.setRequestMethod("POST");
            con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

            StringBuffer urlParameters = new StringBuffer();
            urlParameters.append("token=");
            urlParameters.append(token);
            if( arg != null){
                for( int i = 0; i < arg.length; i++){
                    urlParameters.append("&");
                    urlParameters.append(arg[i]);
                    urlParameters.append("=");
                    urlParameters.append(arg[++i]);
                }
            }
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(urlParameters.toString());
            wr.flush();
            wr.close();


            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            //Print out response
            System.out.println("-------------All Records-----------------");
            System.out.println(response.toString());
            System.out.println("---------------------------------------------------------");


        } catch (ProtocolException e) {
            e.printStackTrace();
            return HTTP_URL_CONNECTION_ERROR;
        } catch (IOException e) {
            e.printStackTrace();
            return HTTP_URL_CONNECTION_ERROR;
        }
        return response.toString();
    }
}
