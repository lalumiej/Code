

/** Author: Jason Lalumiere
package com.capstone.spring.dao;




import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capstone.spring.model.Login;

@Repository
public class LoginDAO {

	@Autowired
	 private SessionFactory sessionFactory;

	    public SessionFactory getSessionFactory() {
	        return sessionFactory;
	    }

	  
	    public void setSessionFactory(SessionFactory sessionFactory) {
	        this.sessionFactory = sessionFactory;
	    }

		public boolean login(String email, String password){
        String query;
        String dbUsername, dbPassword;
        boolean login = false;

        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sums", "root", "root");
            Statement stmt = (Statement) con.createStatement();
            query = "SELECT emails, password from user"
            stmt.executeQuery(query);
            ResultSet rs = stmt.getResultSet();

            while(rs.next()){
                dbUsername = rs.getString("email");
                dbPassword = rs.getString("password");

               if(dbUsername.equals(emails) && dbPassword.equals(password)){

			   {
                    System.out.println("OK");
                    login = true;
                }
                System.out.println(email + password + " " + dbUsername + dbPassword);
            }
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return login;
    }

	  
}

	  

*/

