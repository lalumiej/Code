/** Created By: Jason Lalumiere
package com.capstone.spring.dao;



import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.capstone.spring.model.Registration;


public class RegistrationDAO {

	@Autowired
	 private SessionFactory sessionFactory;

	
	    public SessionFactory getSessionFactory() {
	        return sessionFactory;
	    }


	    public void setSessionFactory(SessionFactory sessionFactory) {
	        this.sessionFactory = sessionFactory;
	    }



	    public void addRegistration(Registration register) {
	        getSessionFactory().getCurrentSession().save(register);
	    }

	

	    public void deleteUser(Registration register) {
	        getSessionFactory().getCurrentSession().delete(register);
	    }



	    public void updateUser(Registration register) {
	        getSessionFactory().getCurrentSession().update(register);
	    }



	    public Registration getRegisteredUserById(int userId) {
	        List list = getSessionFactory().getCurrentSession()
	                .createQuery("from User  where userId=?")
	                .setParameter(0, userId).list();
	        return (Registration)list.get(0);
	    }

	

	    public List<Registration> getRegisteredUsers() {
	        List list = getSessionFactory().getCurrentSession().createQuery("from  Registration").list();
	        return list;
	    }
}

*/