/** Created By: Jason Lalumiere
package com.capstone.spring.model;

import java.sql.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Id;

public class Login {

	private int userId;
    private String userPassword;
    private Date lastLogin;
    private String userEmail;
   
	
    @Id
    @Column(name = "userId", nullable = false, insertable = true, updatable = true)
    public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	@Basic
    @Column(name = "userPassword", nullable = false, insertable = true, updatable = true, length = 255)
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	@Basic
    @Column(name = "userEmail", nullable = false, insertable = true, updatable = true, length = 100)
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	 @Id
	    @Column(name = "lastLogin", nullable = false, insertable = true, updatable = true)
	    public Date getLastLogin() {
			return lastLogin;
		}
		public void setLastLogin(Date lastLogin) {
			this.lastLogin = lastLogin;
		}

	
	 	@Override
	    public boolean equals(Object log) {
	        if (this == log) return true;
	        if (log == null || getClass() != log.getClass()) return false;

	        Login login = (Login) log;

	        if (userId != login.userId) return false;
	        if (userPassword != null ? !userPassword.equals(login.userPassword) : login.userPassword != null) return false;
	        if (userEmail != null ? !userEmail.equals(login.userEmail) : login.userEmail != null) return false;
	        if (lastLogin != null ? !lastLogin.before(login.lastLogin) : login.lastLogin != null) return false;
	  

	        return true;
	    }
	 	
	 		@Override
	 	    public int hashCode() {
	 	        int result = userId;
	 	        result = 31 * result + (userPassword != null ? userPassword.hashCode() : 0);
	 	        result = 31 * result + (userEmail != null ? userEmail.hashCode() : 0);
	 	        result = 31 * result + (lastLogin != null ? lastLogin.hashCode() : 0);
	 	        return result;
	 	    }

    
}

*/