/**
package com.capstone.spring.model;




import java.sql.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Registration {
	
	private int userId;
    private String userPassword;
    private String userFirstName;
    private String userLastName;
    private String userGender;
    private Date userBirth;
    private String userEmail;
    private String userPhone;
	
    @Id
    @Column(name = "userId", nullable = false, insertable = true, updatable = true)
    public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	@Basic
    @Column(name = "userPassword", nullable = false, insertable = true, updatable = true, length = 255)
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	@Basic
	@Column(name = "userLastName", nullable = false, insertable = true, updatable = true, length = 30)
	public String getUserLastName() {
		return userLastName;
	}
	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}
	@Basic
	@Column(name = "userFirstName", nullable = false, insertable = true, updatable = true, length = 30)
	public String getUserFirstName() {
		return userFirstName;
	}
	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}
	@Basic
    @Column(name = "userGender", nullable = false, insertable = true, updatable = true, length = 5)
	public String getUserGender() {
		return userGender;
	}
	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}
	@Basic
    @Column(name = "userBirth", nullable = false, insertable = true, updatable = true)
	public Date getUserBirth() {
		return userBirth;
	}
	public void setUserBirth(Date userBirth) {
		this.userBirth = userBirth;
	}
	@Basic
    @Column(name = "userEmail", nullable = false, insertable = true, updatable = true, length = 100)
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	@Basic
    @Column(name = "userPhone", nullable = true, insertable = true, updatable = true, length = 12)
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	
	 	@Override
	    public boolean equals(Object r) {
	        if (this == r) return true;
	        if (r == null || getClass() != r.getClass()) return false;

	        Registration registrate = (Registration) r;

	        if (userId != registrate.userId) return false;
	        if (userPassword != null ? !userPassword.equals(registrate.userPassword) : registrate.userPassword != null) return false;
	        if (userFirstName != null ? !userFirstName.equals(registrate.userFirstName) : registrate.userFirstName != null)
	            return false;
	        if (userLastName != null ? !userLastName.equals(registrate.userLastName) : registrate.userLastName != null) return false;
	        if (userGender != null ? !userGender.equals(registrate.userGender) : registrate.userGender != null) return false;
	        if (userBirth != null ? !userBirth.equals(registrate.userBirth) : registrate.userBirth != null) return false;
	        if (userEmail != null ? !userEmail.equals(registrate.userEmail) : registrate.userEmail != null) return false;
	        if (userPhone != null ? !userPhone.equals(registrate.userPhone) : registrate.userPhone != null) return false;

	        return true;
	    }
	 	
	 		@Override
	 	    public int hashCode() {
	 	        int result = userId;
	 	        result = 31 * result + (userPassword != null ? userPassword.hashCode() : 0);
	 	        result = 31 * result + (userFirstName != null ? userFirstName.hashCode() : 0);
	 	        result = 31 * result + (userLastName != null ? userLastName.hashCode() : 0);
	 	        result = 31 * result + (userGender != null ? userGender.hashCode() : 0);
	 	        result = 31 * result + (userBirth != null ? userBirth.hashCode() : 0);
	 	        result = 31 * result + (userEmail != null ? userEmail.hashCode() : 0);
	 	        result = 31 * result + (userPhone != null ? userPhone.hashCode() : 0);
	 	        return result;
	 	    }

    
}
*/