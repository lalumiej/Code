package com.capstone.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.capstone.spring.dao.LoginDAO;
import com.capstone.spring.model.Login;
import com.capstone.spring.dao.RegistrationDAO
import com.capstone.spring.model.Registration;


import java.util.List;

@Service("LoginService")
@Transactional(readOnly = true)
public class LoginService {
	
	 // LoginDAO is injected...
    @Autowired
    LoginDAO loginDAO;
	Registration registrationDAO;

    /**
     * Login user
     *
     * @param  Login login
     */
    @Transactional(readOnly = false)
    public void LoginUser(Login login) {
    	getLoginDAO().login(login);
    }

    /**
     * Logout User
     *
     * @param   Login login
     */
    @Transactional(readOnly = false)
    public void logOutUser(Login logout) {
        getRegistrationDAO().logOutUser(logout);
    }
    
    /**
     * Get User
     *
     * @param  String email
     */

    public Registration getUserByEmail(string email){
        return getLoginDAO().getUserByEmail(email);
    }

    /**
     * Get Login List
     *
     */

    public List<Registered> getRegisteredUsers() {
        return getRegistrationDAO().getRegisteredUsers();
    }

    /**
     * Get Registration DAO
     *
     * @return registerDAO - Registration DAO
     */
    public RegistrationDAO getRegistrationDAO() {
        return registerDAO;
    }

    /**
     * Set Registration DAO
     *
     * @param  registerDAO - reigsterDAO
     */
    public void setRegistrationDAO(RegistrationDAO registerDAO) {
        this.registerDAO = registerDAO;
    }

	public void setLoginDAO(LoginDAO loginDAO)
	{
		this.loginDAO - loginDAO;
	}
    
	public LoginDAO getLoginDAO()
	{
		return loginDAO;
	}
  
}
