/** Created By: Jason Lalumiere
package com.capstone.spring.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.capstone.spring.dao.RegistrationDAO;
import com.capstone.spring.model.Registration;


import java.util.List;

@Service("RegistrationService")
@Transactional(readOnly = true)
public class RegistrationService {
	
	 // LoginDAO is injected...
    @Autowired
    RegistrationDAO registerDAO;


    @Transactional(readOnly = false)
    public void registerUser(Registration register) {
    	getRegistrationDAO().addRegistration(register);
    }

 
    @Transactional(readOnly = false)
    public void deleteUser(Registration register) {
        getRegistrationDAO().deleteUser(register);
    }

    @Transactional(readOnly = false)
    public void updateUser(Registration register) {
        getRegistrationDAO().updateUser(register);
    }



    public Registration getRegisteredUserById(int id) {
        return getRegistrationDAO().getRegisteredUserById(id);
    }


    public List<Registration> getRegisteredUsers() {
        return getRegistrationDAO().getRegisteredUsers();
    }

   
    public RegistrationDAO getRegistrationDAO() {
        return registerDAO;
    }

   
    public void setRegistrationDAO(RegistrationDAO registerDAO) {
        this.registerDAO = registerDAO;
    }

}
*/