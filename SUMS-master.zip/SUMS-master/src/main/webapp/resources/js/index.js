function showActivities() {
    document.getElementById("iframeCenter").src = "./webpages/club_member/member_activities.xhtml";
}

function showCalendar() {
    document.getElementById("iframeCenter").src = "./webpages/club_member/activity_calendar.xhtml";
}

function showClubs() {
    document.getElementById("iframeCenter").src = "./webpages/club_member/member_clubs.xhtml";
}

function showMessages() {
    document.getElementById("iframeCenter").src = "./webpages/club_member/member_messages.xhtml";
}

function showProfile() {
    document.getElementById("iframeCenter").src = "./webpages/club_member/member_profile.xhtml";
}

function showSettings() {
    document.getElementById("iframeCenter").src = "./webpages/club_member/member_settings.xhtml";
}


function showUsers() {
    document.getElementById("iframeCenter").src = "./webpages/club_manager/users.xhtml";
}

function showClubSettings() {
    document.getElementById("iframeCenter").src = "./webpages/club_manager/club_settings.xhtml";
}

function showClubActivities() {
    document.getElementById("iframeCenter").src = "./webpages/club_manager/club_activities.xhtml";
}

function showClubIntro() {
    document.getElementById("iframeCenter").src = "./webpages/club_manager/club_intro.xhtml";
}


